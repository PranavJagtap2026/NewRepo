import express from "express";
import bodyParser from "body-parser";
import path from "path";
import { fileURLToPath } from "url";
import { storeCertificate, verifyCertificate, revokeCertificate, revokeByHash, getAllCertificates } from "./certificate.js";
import crypto from "crypto";
import puppeteer from "puppeteer";

const app = express();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public")));

// Simple in-memory session store for demo
const sessions = {};
function createSession() {
  const sid = crypto.randomBytes(16).toString("hex");
  sessions[sid] = { created: Date.now() };
  return sid;
}
function parseCookie(req){
  const hdr = req.headers.cookie || "";
  const parts = hdr.split(';').map(s=>s.trim()).filter(Boolean);
  const obj = {};
  parts.forEach(p=>{
    const idx = p.indexOf('=');
    if(idx>0){
      const k = p.slice(0,idx).trim();
      const v = p.slice(idx+1).trim();
      obj[k]=v;
    }
  });
  return obj;
}
function requireAuth(req, res, next) {
  const cookies = parseCookie(req);
  const sid = cookies.sid;
  if (sid && sessions[sid]) return next();
  // Not authenticated -> check if API endpoint
  if (req.path.startsWith('/api/')) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  // For non-API endpoints, send login page
  return res.sendFile(path.join(__dirname, "public/login.html"));
}

// Root: redirect to login page
app.get("/", (req, res) => {
  res.redirect("/login");
});

// Login page
app.get("/login", (req, res) => {
  res.sendFile(path.join(__dirname, "public/login.html"));
});

app.get("/dashboard", requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, "public/dashboard.html"));
});

// Admin page
app.get("/admin", (req, res) => {
  res.sendFile(path.join(__dirname, "public/admin.html"));
});

// Simple admin login (DEMO: replace with real auth in production)
// Admin login (legacy admin page)
app.post("/admin-login", (req, res) => {
  const { email, password } = req.body;
  if (email === "admin@example.com" && password === "adminpass") {
    const sid = createSession();
    res.setHeader('Set-Cookie', `sid=${sid}; HttpOnly; Path=/`);
    return res.redirect('/');
  }
  return res.sendFile(path.join(__dirname, "public/admin.html"));
});

// Login endpoint used by login.html
app.post('/login', (req, res) => {
  const { email, password } = req.body;
  if (email === 'admin@example.com' && password === 'adminpass') {
    const sid = createSession();
    res.setHeader('Set-Cookie', `sid=${sid}; HttpOnly; Path=/`);
    return res.json({ ok: true, redirect: '/dashboard' });
  }
  return res.status(401).json({ ok: false });
});

// Logout
app.post('/logout', (req,res)=>{
  const sid = req.headers.cookie && req.headers.cookie.split('sid=')[1];
  if(sid) delete sessions[sid];
  res.setHeader('Set-Cookie','sid=; Max-Age=0; Path=/');
  return res.json({ok:true});
});

// Store certificate
// Legacy store endpoint kept for compatibility (not used by new UI)
app.post("/store", async (req, res) => {
  const { studentID, name, course, date } = req.body;
  const result = await storeCertificate({ studentID, name, institution: '', course, date });
  res.send(`
    <h3>Certificate Stored</h3>
    <p>Hash: ${result.hash}</p>
    <p>QR Code: <img src="${result.qrPath}" /></p>
    <a href="/">Back</a>
  `);
});

// API: generate certificate from dashboard
app.post('/api/generate', requireAuth, async (req,res)=>{
  console.log('Certificate generation request:', req.body);
  const cert = req.body;
  const result = await storeCertificate(cert);
  console.log('Certificate generation result:', result);
  res.json(result);
});

// API: list certificates
app.get('/api/certificates', requireAuth, (req,res)=>{
  const items = getAllCertificates();
  console.log('Certificate list requested, returning:', items.length, 'certificates');
  res.json(items);
});

// Test endpoint to check authentication
app.get('/api/test-auth', requireAuth, (req, res) => {
  res.json({ authenticated: true, message: 'Auth working' });
});

// Verify by hash (can also use QR link)
app.get("/verify", (req, res) => {
  res.sendFile(path.join(__dirname, "public/verify.html"));
});

// API: Verify certificate
app.post("/api/verify", requireAuth, (req, res) => {
  const { hash } = req.body;
  const result = verifyCertificate(hash);
  res.json(result);
});

// API: Revoke certificate by hash
app.post("/api/revoke", requireAuth, (req, res) => {
  console.log('Revoke request received:', req.body);
  const { hash } = req.body;
  if (!hash) {
    console.log('No hash provided');
    return res.status(400).json({ success: false, error: 'Hash is required' });
  }
  const success = revokeByHash(hash);
  console.log('Revoke result:', success);
  res.json({ success });
});

// Legacy verify endpoint
app.post("/verify-cert", requireAuth, (req, res) => {
  const { hash } = req.body;
  // Redirect to the verify page with the hash as a query parameter
  // This allows the new verify page to handle the logic
  res.redirect(`/verify?hash=${hash}`);
});

// Revoke certificate
// Revoke by studentID (legacy)
app.post("/revoke", requireAuth, (req, res) => {
  const { studentID } = req.body;
  const success = revokeCertificate(studentID);
  res.send(`
    <h3>Revoke Certificate</h3>
    <p>${success ? "Revoked successfully" : "Certificate not found"}</p>
    <a href="/">Back</a>
  `);
});

// Revoke by hash (new)
app.post('/revoke-by-hash', requireAuth, (req,res)=>{
  const { hash } = req.body;
  const ok = revokeByHash(hash);
  res.send(`
    <h3>Revoke Certificate</h3>
    <p>${ok ? "Revoked successfully" : "Certificate not found"}</p>
    <a href="/revoke">Back</a>
  `);
});

// PDF Download endpoint
app.get('/api/download-pdf/:hash', requireAuth, async (req, res) => {
  try {
    const { hash } = req.params;
    const certificate = verifyCertificate(hash);
    
    if (!certificate.valid) {
      return res.status(404).json({ error: 'Certificate not found or invalid' });
    }

    const student = certificate.student;
    
    // Get QR code path for this certificate
    const { getAllCertificates } = await import('./certificate.js');
    const allCerts = getAllCertificates();
    const certData = allCerts.find(c => c.hash === hash);
    const qrCodePath = certData ? certData.qrPath : null;
    
    // Read QR code file and convert to base64
    let qrCodeBase64 = null;
    if (qrCodePath) {
      try {
        const fs = await import('fs');
        // The qrCodePath is like "/qrcodes/student.png", so we need "./public/qrcodes/student.png"
        const fullPath = `.${qrCodePath}`;
        console.log('Looking for QR code at:', fullPath);
        const qrCodeBuffer = fs.readFileSync(fullPath);
        qrCodeBase64 = `data:image/png;base64,${qrCodeBuffer.toString('base64')}`;
        console.log('QR code loaded successfully, size:', qrCodeBuffer.length, 'bytes');
      } catch (error) {
        console.error('Error reading QR code file:', error);
        console.log('QR code path was:', qrCodePath);
        console.log('Full path attempted:', `.${qrCodePath}`);
        
        // Try alternative path
        try {
          const altPath = `./public/qrcodes/${certData.name.replace(/\s+/g, '_').toLowerCase()}.png`;
          console.log('Trying alternative path:', altPath);
          const qrCodeBuffer = fs.readFileSync(altPath);
          qrCodeBase64 = `data:image/png;base64,${qrCodeBuffer.toString('base64')}`;
          console.log('QR code loaded from alternative path, size:', qrCodeBuffer.length, 'bytes');
        } catch (altError) {
          console.error('Alternative path also failed:', altError);
        }
      }
    } else {
      console.log('No QR code path found for certificate');
    }

    // Generate HTML for the certificate
    const certificateHTML = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Certificate - ${student.name}</title>
        <style>
          body {
            font-family: 'Poppins', 'Arial', sans-serif;
            margin: 0;
            padding: 40px;
            background: #F4F6F8;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
          }
          .certificate {
            background: white;
            padding: 60px;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            text-align: center;
            max-width: 800px;
            width: 100%;
            position: relative;
            border: 3px solid #0A1F44;
          }
          .certificate::before {
            content: '';
            position: absolute;
            top: 20px;
            left: 20px;
            right: 20px;
            bottom: 20px;
            border: 2px solid #2563EB;
            border-radius: 10px;
            pointer-events: none;
          }
          .header {
            color: #0A1F44;
            font-size: 2.5em;
            font-weight: 600;
            margin-bottom: 20px;
            text-transform: uppercase;
            letter-spacing: 2px;
          }
          .subtitle {
            color: #6B7280;
            font-size: 1.2em;
            margin-bottom: 40px;
          }
          .student-name {
            font-size: 3em;
            font-weight: 600;
            color: #1F2937;
            margin: 30px 0;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.1);
          }
          .course-name {
            font-size: 1.8em;
            color: #2563EB;
            font-weight: 600;
            margin: 20px 0;
          }
          .details {
            display: flex;
            justify-content: space-around;
            margin: 40px 0;
            flex-wrap: wrap;
          }
          .detail-item {
            background: #f8f9fa;
            padding: 15px 25px;
            border-radius: 10px;
            margin: 10px;
            border-left: 4px solid #2563EB;
          }
          .detail-label {
            font-weight: 600;
            color: #2563EB;
            font-size: 0.9em;
            text-transform: uppercase;
            letter-spacing: 1px;
          }
          .detail-value {
            font-size: 1.1em;
            color: #1F2937;
            margin-top: 5px;
          }
          .verification-section {
            margin-top: 40px;
            padding: 20px;
            background: #f8f9fa;
            border-radius: 10px;
            border: 1px solid #e0e0e0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
          }
          .hash-info {
            flex: 1;
            min-width: 300px;
            margin-right: 20px;
          }
          .hash-label {
            font-weight: 600;
            color: #6B7280;
            font-size: 0.9em;
            margin-bottom: 10px;
          }
          .hash-value {
            font-family: 'Courier New', monospace;
            font-size: 0.8em;
            color: #1F2937;
            word-break: break-all;
            background: white;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #E5E7EB;
          }
          .qr-section {
            text-align: center;
            flex: 0 0 auto;
          }
          .qr-label {
            font-weight: 600;
            color: #6B7280;
            font-size: 0.9em;
            margin-bottom: 10px;
          }
          .qr-code {
            width: 120px;
            height: 120px;
            border: 2px solid #2563EB;
            border-radius: 8px;
            background: white;
            padding: 5px;
          }
          .footer {
            margin-top: 30px;
            color: #6B7280;
            font-size: 0.9em;
          }
          .date {
            margin-top: 20px;
            color: #2563EB;
            font-weight: 600;
          }
        </style>
      </head>
      <body>
        <div class="certificate">
          <div class="header">Certificate of Achievement</div>
          <div class="subtitle">This is to certify that</div>
          <div class="student-name">${student.name}</div>
          <div class="subtitle">has successfully completed the course</div>
          <div class="course-name">${student.course}</div>
          
          <div class="details">
            <div class="detail-item">
              <div class="detail-label">Institution</div>
              <div class="detail-value">${student.institution}</div>
            </div>
            <div class="detail-item">
              <div class="detail-label">Marks</div>
              <div class="detail-value">${student.marks || 'N/A'}</div>
            </div>
            <div class="detail-item">
              <div class="detail-label">CGPA</div>
              <div class="detail-value">${student.cgpa || 'N/A'}</div>
            </div>
            <div class="detail-item">
              <div class="detail-label">Backlogs</div>
              <div class="detail-value">${student.backlogs || '0'}</div>
            </div>
          </div>
          
          <div class="verification-section">
            <div class="hash-info">
              <div class="hash-label">Certificate Hash (SHA256)</div>
              <div class="hash-value">${hash}</div>
            </div>
            ${qrCodeBase64 ? `
            <div class="qr-section">
              <div class="qr-label">QR Code for Verification</div>
              <img src="${qrCodeBase64}" alt="QR Code" class="qr-code" />
            </div>
            ` : ''}
          </div>
          
          <div class="footer">
            <div class="date">Issued on: ${new Date().toLocaleDateString()}</div>
            <p>This certificate is digitally signed and can be verified using the hash above or by scanning the QR code.</p>
          </div>
        </div>
      </body>
      </html>
    `;

    // Generate PDF using Puppeteer
    const browser = await puppeteer.launch({ 
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-web-security']
    });
    const page = await browser.newPage();
    await page.setContent(certificateHTML, { 
      waitUntil: 'domcontentloaded',
      timeout: 60000 
    });
    
    const pdfBuffer = await page.pdf({
      format: 'A4',
      printBackground: true,
      margin: {
        top: '0.5in',
        right: '0.5in',
        bottom: '0.5in',
        left: '0.5in'
      }
    });
    
    await browser.close();
    
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="certificate-${student.name.replace(/\s+/g, '-')}.pdf"`);
    res.send(pdfBuffer);
    
  } catch (error) {
    console.error('PDF generation error:', error);
    res.status(500).json({ error: 'Failed to generate PDF' });
  }
});

app.listen(3000, () => console.log("Server running on http://localhost:3000"));
