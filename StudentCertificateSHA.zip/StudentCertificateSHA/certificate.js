import crypto from "crypto";
import fs from "fs";
import QRCode from "qrcode";

const DB_FILE = "./db.json";
const QR_FOLDER = "./public/qrcodes/";

// Ensure QR folder exists
if (!fs.existsSync(QR_FOLDER)) fs.mkdirSync(QR_FOLDER, { recursive: true });

// Load database and normalize to hash-keyed store
let certificateDB = {};
if (fs.existsSync(DB_FILE)) {
  try {
    const raw = JSON.parse(fs.readFileSync(DB_FILE, "utf-8"));
    // If the file uses studentID keys, migrate to hash-keyed
    Object.values(raw).forEach((entry) => {
      if (entry && entry.hash) certificateDB[entry.hash] = entry;
    });
  } catch (e) {
    certificateDB = {};
  }
}

// Generate SHA256 hash from full certificate details
export function generateCertificateHash({ name, institution, course, marks, cgpa, backlogs }) {
  const data = `${name}|${institution}|${course}|${marks || ""}|${cgpa || ""}|${backlogs || ""}`;
  return crypto.createHash("sha256").update(data).digest("hex");
}

// Save database
function saveDB() {
  fs.writeFileSync(DB_FILE, JSON.stringify(certificateDB, null, 2));
}

// Store certificate (accepts an object with fields)
export async function storeCertificate(cert) {
  const certHash = generateCertificateHash(cert);
  const entry = Object.assign({}, cert, { hash: certHash, revoked: false });
  certificateDB[certHash] = entry;
  saveDB();

  // sanitize name for filename
  function sanitizeFilename(s){
    return (s||"").toString().toLowerCase().replace(/[^a-z0-9_-]+/g, '_').replace(/^_+|_+$/g,'').slice(0,60);
  }

  const baseName = sanitizeFilename(`${cert.name || 'student'}`);
  const fileName = `${baseName}.png`;
  const qrPath = `${QR_FOLDER}${fileName}`;
  const qrData = `http://localhost:3000/verify?hash=${certHash}`;
  await QRCode.toFile(qrPath, qrData);

  return { hash: certHash, qrPath: `/qrcodes/${fileName}`, entry };
}

// Verify certificate by hash
export function verifyCertificate(hash) {
  const entry = certificateDB[hash];
  if (!entry) return { valid: false, reason: "not_found" };
  if (entry.revoked) return { valid: false, reason: "revoked", student: entry };
  return { valid: true, student: entry };
}

// Revoke certificate by hash
export function revokeByHash(hash) {
  if (!certificateDB[hash]) return false;
  certificateDB[hash].revoked = true;
  saveDB();
  return true;
}

// Backwards-compat revoke by studentID (keeps older behavior)
export function revokeCertificate(studentID) {
  const entry = Object.values(certificateDB).find((c) => c.studentID === studentID);
  if (!entry) return false;
  entry.revoked = true;
  saveDB();
  return true;
}

export function getAllCertificates() {
  return Object.values(certificateDB);
}
