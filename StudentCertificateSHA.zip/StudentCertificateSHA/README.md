# BlockCred - Blockchain-based Student Certificate System

A complete web application for managing student certificates using blockchain technology with SHA256 hashing and QR code generation.

## Features

### 🔐 Admin Authentication
- **First Page**: Admin login page (username: `admin@example.com`, password: `adminpass`)
- Secure session management with HTTP-only cookies
- Automatic redirect to login if not authenticated

### 📜 Certificate Management
- **Enroll Certificates**: Create digital certificates with student details
- **Verify Certificates**: Verify certificate authenticity using hash
- **Dashboard**: View all issued certificates with status

### 🎓 Certificate Details
- Full Name of Student
- Name of Institution
- Course Name
- Marks Obtained
- Overall CGPA
- Number of Backlogs

### 🔒 Blockchain Features
- **SHA256 Hashing**: Each certificate gets a unique SHA256 hash
- **QR Code Generation**: Automatic QR code generation for each certificate
- **Digital Verification**: Verify certificates using hash or QR code
- **Immutable Records**: Certificate data stored in JSON database

### 📄 PDF Generation
- **Download PDF**: Generate and download professional PDF certificates
- **Beautiful Design**: Modern certificate layout with gradients and styling
- **Hash Inclusion**: PDF includes the certificate hash for verification

### 🎨 Modern UI
- **Responsive Design**: Works on desktop and mobile devices
- **Beautiful Gradients**: Blue and purple color scheme
- **Smooth Animations**: Hover effects and transitions
- **Card-based Layout**: Clean, organized interface

## Installation & Setup

### Prerequisites
- Node.js (v14 or higher)
- npm

### Installation Steps

1. **Clone or download the project**
   ```bash
   cd StudentCertificateSHA
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start the server**
   ```bash
   node server.js
   ```

4. **Access the application**
   - Open your browser and go to `http://localhost:3000`
   - You'll be redirected to the login page

## Usage

### 1. Admin Login
- Navigate to `http://localhost:3000`
- Use credentials:
  - **Email**: `admin@example.com`
  - **Password**: `adminpass`

### 2. Enroll a Certificate
- Click on "Enroll a Certificate" tab
- Fill in all student details:
  - Full Name
  - Institution Name
  - Course Name
  - Marks Obtained
  - CGPA
  - Number of Backlogs
- Click "Generate Certificate"
- View the generated certificate with hash and QR code
- Download PDF certificate

### 3. Verify a Certificate
- Click on "Verify a Certificate" tab
- Enter the certificate hash or scan QR code
- View verification results
- Download PDF if certificate is valid

### 4. Dashboard
- Click on "Dashboard" tab
- View all issued certificates
- See certificate status (Valid/Revoked)
- Download PDF certificates

## Technical Details

### Architecture
- **Backend**: Node.js with Express.js
- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Database**: JSON file storage (`db.json`)
- **PDF Generation**: Puppeteer
- **QR Code**: qrcode library
- **Hashing**: Node.js crypto module (SHA256)

### File Structure
```
StudentCertificateSHA/
├── server.js              # Main server file
├── certificate.js         # Certificate logic and database
├── package.json           # Dependencies
├── db.json               # Certificate database
├── public/               # Frontend files
│   ├── index.html        # Main page (redirects to login)
│   ├── login.html        # Admin login page
│   ├── dashboard.html    # Main application interface
│   ├── verify.html       # Public verification page
│   ├── admin.html        # Legacy admin page
│   ├── revoke.html       # Certificate revocation
│   ├── css/
│   │   ├── style.css     # Main stylesheet
│   │   └── styles.css    # Additional styles
│   └── qrcodes/          # Generated QR code images
└── node_modules/         # Dependencies
```

### API Endpoints
- `GET /` - Redirects to login
- `GET /login` - Login page
- `POST /login` - Admin authentication
- `GET /dashboard` - Main dashboard (requires auth)
- `POST /api/generate` - Generate certificate
- `POST /api/verify` - Verify certificate
- `GET /api/certificates` - List all certificates
- `GET /api/download-pdf/:hash` - Download PDF certificate
- `POST /logout` - Admin logout

### Security Features
- Session-based authentication
- HTTP-only cookies
- SHA256 hashing for certificate integrity
- QR code verification
- Certificate revocation capability

## Key Functions

### Certificate Generation
```javascript
// Generate SHA256 hash from certificate data
function generateCertificateHash({ name, institution, course, marks, cgpa, backlogs }) {
  const data = `${name}|${institution}|${course}|${marks || ""}|${cgpa || ""}|${backlogs || ""}`;
  return crypto.createHash("sha256").update(data).digest("hex");
}
```

### PDF Generation
- Uses Puppeteer to generate PDF certificates
- Professional styling with gradients and borders
- Includes certificate hash for verification
- Automatic filename generation

### QR Code Integration
- QR codes link to verification page with hash
- Automatic QR code generation for each certificate
- Stored in `/public/qrcodes/` directory

## Browser Compatibility
- Chrome (recommended)
- Firefox
- Safari
- Edge

## Troubleshooting

### Common Issues
1. **Port 3000 already in use**
   - Change port in `server.js` line 370
   - Update all localhost:3000 references

2. **PDF generation fails**
   - Ensure Puppeteer is properly installed
   - Check system permissions

3. **QR codes not generating**
   - Verify `qrcodes` folder exists
   - Check file permissions

### Development
- Server runs on `http://localhost:3000`
- Database stored in `db.json`
- QR codes in `public/qrcodes/`
- Logs printed to console

## Future Enhancements
- Database integration (MongoDB/PostgreSQL)
- Email certificate delivery
- Batch certificate generation
- Advanced admin panel
- Certificate templates
- Digital signatures
- Blockchain integration

## License
This project is for educational and demonstration purposes.

---

**BlockCred - Built with ❤️ using Node.js, Express.js, and modern web technologies**
